package com.example.storyapp

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.storyapp.model.MainViewModel
import com.example.storyapp.model.ViewModelFactory
import com.example.storyapp.databinding.ActivityMainBinding
import com.example.storyapp.model.StoryViewModel
import com.example.storyapp.ui.story.StoryActivity
import com.example.storyapp.ui.theme.StoryAppTheme
import com.example.storyapp.ui.user.LoginActivity
import com.example.storyapp.ui.user.RegisterActivity

class MainActivity : AppCompatActivity() {
    private val viewModel: StoryViewModel by viewModels { ViewModelFactory.getInstance(this) }
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        viewModel.getSession().observe(this) { user ->
            val token = user.token
            viewModel.getStories(token)
            if (user.isLogin) {
                startActivity(Intent(this, StoryActivity::class.java))
                finish()
            }else{
                setAction()
                playAnimation()
            }
        }
    }
    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.imgWelcome, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()
        val login = ObjectAnimator.ofFloat(binding.loginButton, View.ALPHA, 1f).setDuration(100)
        val signup = ObjectAnimator.ofFloat(binding.registerButton, View.ALPHA, 1f).setDuration(100)
        val title = ObjectAnimator.ofFloat(binding.titleWelcome, View.ALPHA, 1f).setDuration(100)
        val titleContent = ObjectAnimator.ofFloat(binding.titleContent, View.ALPHA, 1f).setDuration(100)

        val together = AnimatorSet().apply {
            playTogether(login, signup)
        }

        AnimatorSet().apply {
            playSequentially(title, titleContent, together)
            start()
        }
    }


    fun setAction(){
        binding.loginButton.setOnClickListener {
            val toLoginScreen = Intent(this@MainActivity, LoginActivity::class.java)
            startActivity(toLoginScreen)
        }
        binding.registerButton.setOnClickListener {
            val toRegisterScreen = Intent(this@MainActivity, RegisterActivity::class.java)
            startActivity(toRegisterScreen)
        }
    }
}
