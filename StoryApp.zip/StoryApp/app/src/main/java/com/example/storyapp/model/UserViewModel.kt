package com.example.storyapp.model
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.storyapp.data.AllRepository
import kotlinx.coroutines.launch

class UserViewModel(private val repository: AllRepository): ViewModel(){
    fun saveSession(user: UserModel){
        Log.d("LoginVM",user.toString())
        viewModelScope.launch {
            repository.saveSession(user)
        }
    }
    fun login(email:String, password: String) = repository.userLogin(email, password)
    fun register(name:String, email:String, password: String) = repository.userRegister(name,email,password)
}