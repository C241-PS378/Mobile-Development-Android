package com.example.storyapp.ui.story

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.example.storyapp.MainActivity
import com.example.storyapp.R
import com.example.storyapp.databinding.ActivityDetailStoryBinding
import com.example.storyapp.model.StoryViewModel
import com.example.storyapp.model.ViewModelFactory

class DetailStoryActivity : AppCompatActivity() {
    private val viewModel: StoryViewModel by viewModels { ViewModelFactory.getInstance(this) }
    private lateinit var binding: ActivityDetailStoryBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val id = intent.getStringExtra(ID).toString()
        showLoading(true)
        showLoading(
            true
        )
        viewModel.getSession().observe(this) { user ->
            val token = user.token
            if (!user.isLogin) {
                startActivity(Intent(this, MainActivity::class.java))
                finish()
            } else {
                viewModel.getStoryDetail(id, token)
                showDetailStory()
            }
        }
    }

    private fun showDetailStory() {
        viewModel.detailStory.observe(this) { content ->
            Glide.with(this@DetailStoryActivity)
                .load(content.photoUrl)
                .into(binding.detailPhoto)
            binding.detailName.text = content.name
            binding.detailDescription.text = content.description
            showLoading(false)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val ID = "extra_id"
    }
}