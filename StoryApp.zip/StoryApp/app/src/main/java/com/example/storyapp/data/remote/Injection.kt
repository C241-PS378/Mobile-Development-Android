package com.example.storyapp.data.remote

import com.example.storyapp.data.UserPreference
import kotlinx.coroutines.runBlocking
import android.content.Context
import com.example.storyapp.data.AllRepository
import com.example.storyapp.data.dataStore
import com.example.storyapp.data.remote.retrofit.ApiConfig
import kotlinx.coroutines.flow.first

object Injection {
    fun provideRepository(context:Context): AllRepository{
        val pref = UserPreference.getInstance(context.dataStore)
        val user = runBlocking { pref.getSession().first() }
        val token = user.token
        val apiService = ApiConfig.getApiService(token)
        return AllRepository.getInstance(pref, apiService)
    }
}