package com.example.storyapp.ui.story

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.storyapp.data.AllRepository
import com.example.storyapp.data.remote.response.ListStoryItem
import com.example.storyapp.databinding.ActivityStoryBinding
import com.example.storyapp.databinding.ItemStoryBinding

class StoryAdapter : RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {
    private val stories: MutableList<ListStoryItem> = mutableListOf()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val view = ItemStoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return StoryViewHolder(view)

    }

    override fun getItemCount(): Int {
        return stories.size
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        val story = stories[position]
        holder.bind(story)
    }

    inner class StoryViewHolder(private val binding: ItemStoryBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(item: ListStoryItem) {
            binding.itemName.text = item.name.toString()
            binding.apply {
                Glide.with(binding.root)
                    .load(item.photoUrl)
                    .centerCrop()
                    .into(binding.itemPhoto)
            }
            binding.itemDescription.text = item.description
            binding.cardView.setOnClickListener() {
                val intent = Intent(it.context, DetailStoryActivity::class.java)
                intent.putExtra(DetailStoryActivity.ID, item.id)
                itemView.context.startActivity(intent,
                    ActivityOptionsCompat.makeSceneTransitionAnimation(itemView.context as Activity)
                        .toBundle()
                )
            }
        }
    }

    @SuppressLint("NotifyDataSetChanged")
    fun setStories(newStories: List<ListStoryItem>) {
        Log.e(TAG, "SetStory Adapter")
        stories.clear()
        stories.addAll(newStories)
        notifyDataSetChanged()
    }

    companion object {
        private const val TAG = "Story Adapter"
    }
}