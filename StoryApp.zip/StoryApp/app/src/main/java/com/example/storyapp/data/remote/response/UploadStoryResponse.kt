package com.example.storyapp.data.remote.response

import com.google.gson.annotations.SerializedName

data class UploadStoryResponse(
    @field: SerializedName("resultUS")
    val resultUS: ResultUS? = null,

    @field: SerializedName("error")
    val error: Boolean? = null,

    @field:SerializedName("message")
    val message: String? = null

)

data class ResultUS(
    @field: SerializedName("description")
    val description: String? = null,

    @field: SerializedName("photo")
    val photo: String? = null
)