package com.example.storyapp.model

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.storyapp.data.AllRepository
import com.example.storyapp.data.remote.Injection

class ViewModelFactory private constructor(private val repository: AllRepository) :
    ViewModelProvider.Factory {
    override fun <T: ViewModel> create(modelClass: Class<T>): T{
        return if(modelClass.isAssignableFrom(UserViewModel::class.java)){
            UserViewModel(repository) as T
        } else if(modelClass.isAssignableFrom(StoryViewModel::class.java)){
            StoryViewModel(repository) as T
        }
        else{
          throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: ViewModelFactory? = null

        @JvmStatic
        fun getInstance(context: Context): ViewModelFactory {
            return INSTANCE ?: synchronized(ViewModelFactory::class.java) {
                INSTANCE ?: ViewModelFactory(Injection.provideRepository(context))
                    .also { INSTANCE = it }
            }
        }
    }
}