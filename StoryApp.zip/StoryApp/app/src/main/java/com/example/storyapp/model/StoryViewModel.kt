package com.example.storyapp.model
import android.os.Build
import androidx.annotation.RequiresExtension
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.asLiveData
import androidx.lifecycle.viewModelScope
import com.example.storyapp.data.AllRepository
import kotlinx.coroutines.launch
import java.io.File

class StoryViewModel(private val repository: AllRepository) : ViewModel() {
    val listStories = repository.listStories
    val detailStory = repository.detailStory
    fun getStories(token: String) = repository.getStories(token)

    fun getStoryDetail(id: String, token: String) = repository.getStoryDetail(id, token)

    @RequiresExtension(extension = Build.VERSION_CODES.S, version = 7)
    fun uploadStory(token: String, file: File, description: String) = repository.uploadImage(token, file, description)

    fun getSession(): LiveData<UserModel> {
        return repository.getSession().asLiveData()
    }
    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }
}